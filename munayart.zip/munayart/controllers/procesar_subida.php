<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'artesano') {
    // Redirigir si no es un artesano
    echo "<script>
                    alert('No tienes el rol de Artesano');
                    window.location.href = '../views/loginIniReg.php';
           </script>";
    exit();
}

// Procesar datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $tipo = $_POST['tipo'];
    $precio = $_POST['precio'];
    $material = $_POST['material'];
    $dimensiones = $_POST['dimensiones'];
    $descripcion = $_POST['descripcion'];
    $imagen = $_FILES['imagen'];


    // Definir el directorio de destino según el tipo
    // Definir la carpeta base de imágenes
    $base_dir = "../views/productos/img/";

    // Definir la carpeta específica según la categoría
    switch ($tipo) {
        case 'Aretes':
            $target_dir = $base_dir . "aretes/";
            break;
        case 'Cerámica':
            $target_dir = $base_dir . "ceramicas/";
            break;
        case 'Chompa':
            $target_dir = $base_dir . "chompas/";
            break;
        case 'Collar':
            $target_dir = $base_dir . "collares/";
            break;
        default:
            $target_dir = $base_dir;  // En caso de que no haya categoría seleccionada, lo guarda en la carpeta base
            break;
    }
    $target_file = $target_dir . basename($imagen["name"]);

    // Validar y mover la imagen subida
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Verificar si es una imagen
    $check = getimagesize($imagen["tmp_name"]);
    if ($check === false) {
        echo "<script>alert('El archivo no es una imagen'); window.location.href = '../views/subir_producto.php';</script>";
        
        $uploadOk = 0;
    }

    // Verificar si el archivo ya existe
    if (file_exists($target_file)) {
        echo "<script>alert('El archivo ya existe, cambie el nombre de la imagen'); window.location.href = '../views/subir_producto.php';</script>";
        $uploadOk = 0;
    }

    // Verificar el tamaño del archivo
    if ($imagen["size"] > 500000) {
        echo "<script>alert('Lo sentimos, tu archivo es demasiado grande'); window.location.href = '../views/subir_producto.php';</script>";
        $uploadOk = 0;
    }

    // Permitir ciertos formatos de imagen
    if (!in_array($imageFileType, ['jpg', 'png', 'jpeg', 'gif', 'webp'])) {
        echo "<script>alert('Lo sentimos, solo se permiten archivos JPG, JPEG, PNG, WEBP y GIF'); window.location.href = '../views/subir_producto.php';</script>";
        $uploadOk = 0;
    }

    // Verificar si $uploadOk está establecido en 0 por un error
    if ($uploadOk == 0) {
        echo "<script>alert('Lo sentimos, tu archivo no se pudo subir'); window.location.href = '../views/subir_producto.php';</script>";
    } else {
        // Si todo está bien, mover el archivo a la carpeta de destino
        if (move_uploaded_file($imagen["tmp_name"], $target_file)) {
            //Para mostrar en la Pagina Correctamente
            $base = "../" . $target_file;
            // Guardar datos en la base de datos
            $sql = "INSERT INTO producto (Nombre, Tipo, Precio, Material, Dimensiones,  Imagen, Descripcion, CodArtesano) VALUES ('$nombre', '$tipo', '$precio', '$material', '$dimensiones', '$base', '$descripcion', '{$_SESSION['user_id']}')";
            if ($conn->query($sql) === TRUE) {
                echo "<script>
                    alert('El producto ha sido subido con éxito.');
                    window.location.href = '../views/productos/index.html';
                    </script>";
                exit();
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "<script>alert('Lo sentimos, hubo un error al subir tu archivo'); window.location.href = '../views/subir_producto.php';</script>";
        }
    }

    // Cerrar conexión
    $conn->close();
}
?>
