<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MunayArt</title>

    <!-- =================================
           PRINCIPAL
        ================================== -->

    <!-- FUENTE GOOGLE FONTS : Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- ICONS: Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

    <!-- ICONS: Line Awesome -->
    <link rel="stylesheet"
        href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <!-- Animaciones AOS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css">


    <!-- Mis Estilos -->
    <link rel="stylesheet" href="views/css/estilos.css">

    <!-- =================================
           BOTON MENU
        ================================== -->
    <!-- Estilos para el menú lateral -->
    <style>
        /* El contenedor del menú oculto */
        #menuHorizontal {
            display: none;
            /* Inicialmente oculto */
            position: absolute;
            /* Para que no afecte el flujo del documento */
            height: 40px;
            width: auto;
            top: 5px;
            /* Ajusta según la posición deseada */
            left: -700px;
            /* Ajusta según la posición deseada */
            background-color: #fff;
            /* Cambia el color de fondo según sea necesario */
            border-radius: 5px;
            padding: 0;
            white-space: nowrap;
            display: flex;
            /* Para permitir centrado */
            align-items: center;
            /* Para centrar verticalmente */
        }

        /* Links dentro del menú */
        #menuHorizontal a {
            padding: 5px 8px;
            /* Reduce el espaciado alrededor del texto */
            height: 40px;
            text-decoration: none;
            color: rgb(17, 14, 14);
            font-size: 18px;
            display: flex;
            align-items: center;
            transition: 0.3s;

        }

        /* Cambiar color al pasar el mouse sobre los enlaces */
        #menuHorizontal a:hover {
            background-color: #f17575;
            border-radius: 5px;
        }

        /*boton menu*/
        /* From Uiverse.io by gagan-gv */
        .btn {
            width: 150px;
            height: 50px;
            border-radius: 5px;
            border: none;
            transition: all 0.5s ease-in-out;
            font-size: 20px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight: 600;
            display: flex;
            align-items: center;
            background: #040f16;
            color: #f5f5f5;
            margin-right: -200px;
        }

        .btn:hover {
            box-shadow: 0 0 20px 0px #2e2e2e3a;
        }

        .btn .icon {
            position: absolute;
            height: 40px;
            width: 70px;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 0.5s;
        }

        .btn .text {
            transform: translateX(55px);
        }

        .btn:hover .icon {
            width: 175px;
        }

        .btn:hover .text {
            transition: all 0.5s;
            opacity: 0;
        }

        .btn:focus {
            outline: none;
        }

        .btn:active .icon {
            transform: scale(0.85);
        }
    </style>

    <!-- =================================
           
        ================================== -->
    <?php include 'models/db_connection.php'; 
    // Consultar los tipos únicos de producto desde la base de datos
    $tipoQuery = "SELECT CodArtesano FROM artesano";
    $tipoResult = $conn->query($tipoQuery);
    
    
    
    ?>
</head>

<body>

    <div class="hm-wrapper">

        <!-- =================================
           HEADER MENU
        ================================== -->
        <div class="hm-header">

            <div class="container">
                <div class="header-menu">

                    <div class="hm-logo">
                        <a href="#">
                            <img src="views/productos/img/LogoNombre.png" alt="">
                        </a>
                    </div>
                    <!-- Menú principal -->
                    <nav class="hm-menu">
                        <div id="main">
                            <button class="btn" onclick="toggleMenu()">
                                <span class="icon">
                                    <svg viewBox="0 0 175 80" width="40" height="40">
                                        <rect width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                                        <rect y="30" width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                                        <rect y="60" width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                                    </svg>
                                </span>
                                <span class="text">MENU</span>
                            </button>

                            <div id="menuHorizontal">
                                <a href="views/filtradoProc/indexFilPro.php">Productos</a>
                                
                                <a href="views/subir_producto.php">Artesano</a>
                                <a href="#">Campañas</a>
                                <a href="#">Nosotros</a>
                                <div class="login_menu">
                                    <ul>
                                        <li><a href="#">
                                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                                <span class="padding_10">Cart</span></a>
                                        </li>
                                        <li><a href="views/loginIniReg.php">
                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                <span class="padding_10">Login</span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </nav>

                </div>
            </div>

        </div>

        <!-- =================================
           HEADER MENU Movil
        ================================== -->
        <div class="header-menu-movil">
            <button class="cerrar-menu"><i class="fas fa-times"></i></button>
            <ul>
                <li><a href="#">Productos</a></li>
                <li><a href="#">Campañas</a></li>
                <li><a href="#">Nosotros</a></li>
                <li><a href="#">Contacto</a></li>
            </ul>
        </div>



        <!-- =================================
           BANNER
        ================================== -->
        <div class="hm-banner">
            <div class="img-banner">
                <img src="views/images/img-banner.jpg" alt="">
            </div>
            <a href=""></a>
        </div>

        <!-- =================================
           HOME CATEGROIAS
        ================================== -->
        <div class="hm-page-block">
            <div class="container">
                <div class="header-title">
                    <h1 data-aos="fade-up" data-aos-duration="3000">Categorías</h1>
                </div>

                <div class="hm-grid-category">

                    <div class="grid-item" data-aos="fade-up" data-aos-duration="1000">
                        <a href="#">
                            <img src="views/productos/img/aretes/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;">Aretes</h3>
                            </div>
                        </a>
                    </div>

                    <div class="grid-item" data-aos="fade-up" data-aos-duration="1500">
                        <a href="#">
                            <img src="views/productos/img/ceramicas/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;">Cerámica</h3>
                            </div>
                        </a>
                    </div>

                    <div class="grid-item" data-aos="fade-up" data-aos-duration="2000">
                        <a href="#">
                            <img src="views/productos/img/chompas/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;">Chompa</h3>
                            </div>
                        </a>
                    </div>

                    <div class="grid-item" data-aos="fade-up" data-aos-duration="2000">
                        <a href="#">
                            <img src="views/productos/img/collares/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;">Collar</h3>
                            </div>
                        </a>
                    </div>

                </div>

            </div>
        </div>


        <!-- =================================
           HOME PRODUCTOS DESTACADOS
        ================================== -->
        <div class="hm-page-block bg-fondo">

            <div class="container">

                <div class="header-title" data-aos="fade-up">
                    <h1>Productos populares</h1>
                </div>

                <!-- TABS -->
                <ul class="hm-tabs" data-aos="fade-up">
                    <li class="hm-tab-link">
                        Aretes
                    </li>

                    <li class="hm-tab-link ">
                        Cerámica
                    </li>

                    <li class="hm-tab-link ">
                        Chompa
                    </li>

                    <li class="hm-tab-link ative">
                        En Oferta
                    </li>



                </ul>

                <!-- CONTENIDO DE LOS TABS -->
                <!-- Aretes -->
                <div class="tabs-content" data-aos="fade-up">

                    <div class="grid-product">

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/aretes/01.webp" alt="">
                                </a>
                                <span class="stin stin-new">Nuevo</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Quisque vulputate aliquam</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/aretes/02.webp" alt="">
                                </a>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Praesent nibh lorem, tempus quis est a</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/aretes/03.webp" alt="">
                                </a>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Nunc sit amet justo nec ipsum dolor.</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/aretes/04.webp" alt="">
                                </a>
                                <span class="stin stin-new">Nuevo</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Lorem ipsum dolor sit, amet consectetur</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                    </div>

                </div>

                <!-- Cerámica -->
                <div class="tabs-content" data-aos="fade-up">

                    <div class="grid-product">

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/ceramicas/01.webp" alt="">
                                </a>
                                <span class="stin stin-new">Nuevo</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Quisque vulputate aliquam</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/ceramicas/02.webp" alt="">
                                </a>
                                <span class="stin stin-new">Nuevo</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Praesent nibh lorem, tempus quis est a</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/ceramicas/03.webp" alt="">
                                </a>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Nunc sit amet justo nec ipsum dolor.</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/ceramicas/04.webp" alt="">
                                </a>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Lorem ipsum dolor sit, amet consectetur</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                    </div>

                </div>

                <!-- Chompa -->
                <div class="tabs-content" data-aos="fade-up">

                    <div class="grid-product">

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/chompas/01.webp" alt="">
                                </a>
                                <span class="stin stin-new">Nuevo</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Quisque vulputate aliquam</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/chompas/02.webp" alt="">
                                </a>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Praesent nibh lorem, tempus quis est a</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/chompas/03.webp" alt="">
                                </a>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Nunc sit amet justo nec ipsum dolor.</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/chompas/04.webp" alt="">
                                </a>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Lorem ipsum dolor sit, amet consectetur</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                    </div>

                </div>

                <!-- En oferta -->
                <div class="tabs-content" data-aos="fade-up">

                    <div class="grid-product">

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/chompas/05.webp" alt="">
                                </a>
                                <span class="stin stin-oferta">Oferta</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Quisque vulputate aliquam</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                    <span class="thash">S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/chompas/04.webp" alt="">
                                </a>
                                <span class="stin stin-oferta">Oferta</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Praesent nibh lorem, tempus quis est a</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                    <span class="thash">S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/aretes/02.webp" alt="">
                                </a>
                                <span class="stin stin-oferta">Oferta</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Nunc sit amet justo nec ipsum dolor.</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>

                                    <span class="thash">S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                        <div class="product-item">
                            <div class="p-portada">
                                <a href="">
                                    <img src="views/productos/img/ceramicas/06.webp" alt="">
                                </a>
                                <span class="stin stin-oferta">Oferta</span>
                            </div>

                            <div class="p-info">
                                <a href="">
                                    <h3>Lorem ipsum dolor sit, amet consectetur</h3>
                                </a>
                                <div class="precio">
                                    <span>S/ 00.00</span>
                                    <span class="thash">S/ 00.00</span>
                                </div>
                                <a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================
           MEJORES ARTESANOS
        ================================== -->
        <div class="hm-page-block bg-fondo"></div>

        <div class="container">

            <div class="header-title" data-aos="fade-up">
                <h1>Mejores Artesanos</h1>
            </div>

            <iframe src="views/MejorArt.php" style="width: 100%; height: 600px; border: none;"></iframe>
            


        </div>

    </div>


    <!-- =================================
           FOOTER
        ================================== -->
    <footer>

        <div class="container">

            <div class="foo-row">
                <div class="foo-col">
                    <h2>Suscríbete <br>a nuestro newsletter</h2>
                    <form action="" method="GET">

                        <div class="f-input">
                            <input type="text" placeholder="Ingrese su correo">
                            <button type="submit" class="hm-btn-round btn-primary"><i
                                    class="far fa-paper-plane"></i></button>
                        </div>
                    </form>

                </div>

                <div class="foo-col">
                    <ul>
                        <li><a href="http://">Productos</a></li>
                        <li><a href="http://">Campañas</a></li>
                        <li><a href="http://">Nosotros</a></li>
                        <li><a href="http://">Contacto</a></li>
                        <
                    </ul>
                </div>

            </div>

        </div>

    </footer>

    <div class="foo-copy">
        <div class="container">
            <p>MunayArt 2024 © Todos los derechos reservados</p>
        </div>
    </div>

    </div>

    <!-- Animaciones : AOS-->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

    <!-- Mi Script -->
    <script src="views/js/app.js"></script>

    <script>

        AOS.init({
            duration: 1200,
        })


    </script>

    <!-- =================================
           BOTON MENU
        ================================== -->
    <!-- Scripts para funcionalidad del menú -->
    <script>
        // Aseguramos que el menú esté oculto cuando se carga la página
        window.onload = function () {
            document.getElementById("menuHorizontal").style.display = "none";
        };

        // Función para mostrar y ocultar el menú horizontal
        function toggleMenu() {
            var menu = document.getElementById("menuHorizontal");
            if (menu.style.display === "none" || menu.style.display === "") {
                menu.style.display = "flex"; // Muestra el menú
            } else {
                menu.style.display = "none";  // Oculta el menú
            }
        }
    </script>

</body>

</html>